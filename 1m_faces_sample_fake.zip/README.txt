1 million fake faces

By, Alexander Reben

ANTEPOSSIBLE LLC

http://www.areben.com
@artBoffin

Licensed under Creative Commons Attribution-NonCommercial 4.0 International

---

Content generated from StyleGAN algorithm and model licensed under CC BY-NC 4.0 by NVIDIA CORPORATION

A Style-Based Generator Architecture for Generative Adversarial Networks
Tero Karras (NVIDIA), Samuli Laine (NVIDIA), Timo Aila (NVIDIA)
http://stylegan.xyz/paper